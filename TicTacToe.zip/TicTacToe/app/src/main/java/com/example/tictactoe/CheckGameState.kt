package com.example.tictactoe


import android.renderscript.ScriptIntrinsicYuvToRGB
import android.util.Log

data class GameState(var winner: String = "", var endGame: Boolean = false, var crosses: Int = 0, var circles: Int = 0)


fun checkGameState(buttons: Array<Array<ButtonState>>): GameState {

    var gameState = GameState()
    for (line in buttons) {
        for (button in line) {
            addScore(gameState, button)
        }
        gameState = returnGameState(gameState)
        if (gameState.endGame) return gameState
    }
    for (i in 0 until buttons.size) {
        for (line in buttons) {
            addScore(gameState, line[i])
        }
        gameState = returnGameState(gameState)
        if (gameState.endGame) return gameState
    }
    for (i in 0 until buttons.size) {
        addScore(gameState,buttons[i][i])
    }
    gameState = returnGameState(gameState)
    if (gameState.endGame) return gameState
    for (i in 0 until buttons.size) {
        addScore(gameState,buttons[2-i][i])
    }
    gameState = returnGameState(gameState)
    if (gameState.endGame) return gameState
    return isDraw(buttons)
}

private fun returnGameState(gameState: GameState): GameState {
    if (gameState.crosses == 3) return GameState("crosses", true)
    else if (gameState.circles == 3) return GameState("circles", true)
    else return GameState()
}

private fun addScore(gameState: GameState, buttonState: ButtonState): GameState {
    if (buttonState.getValue() == "cross") gameState.crosses++
    else if (buttonState.getValue() == "circle") gameState.circles++
    return gameState
}
private fun isDraw(buttons: Array<Array<ButtonState>>):GameState{
    var clickedCounter = 0
    for (line in buttons){
        for (button in line){
            clickedCounter += if (button.isClicked()) 1 else 0
        }
    }
    return if (clickedCounter==9) GameState("draw",true) else GameState()
}