package com.example.tictactoe

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.tictactoe.R
import java.util.*

class MainActivity : AppCompatActivity() {
    private var buttons: Array<Array<ButtonState>>? = null
    private var crossPlays = Random().nextBoolean()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val mainLayout = findViewById<LinearLayout>(R.id.mainLayout)
        val secondaryLayout = setPlayersTurnLayout(crossPlays,mainLayout)
        mainLayout.gravity = Gravity.CENTER
        mainLayout.setBackgroundColor(Color.WHITE)
        buttons = buildButtons(mainLayout,  secondaryLayout.getChildAt(1) as ImageButton)
    }

    private fun buildButtons(mainLayout: LinearLayout, imageButton: ImageButton): Array<Array<ButtonState>> {
        var buttons = arrayOf<Array<ButtonState>>()
        var counter = 0
        for (i in 1..3) {
            var buttonStates = arrayOf<ButtonState>()
            var linearLayout = LinearLayout(applicationContext)
            linearLayout.gravity = Gravity.CENTER_HORIZONTAL
            for (j in 1..3) {
                if (j > 1) {
                    var space = Space(applicationContext)
                    space.minimumWidth = 20
                    linearLayout.addView(space)

                }
                buttonStates += ButtonState(makeButtonStyle(counter,imageButton), counter)
                linearLayout.addView(buttonStates.last().getButton())
                counter++
            }
            if (i > 1) {
                var space = Space(applicationContext)
                space.minimumHeight = 20
                space.setBackgroundColor(Color.WHITE)
                val display = DisplayMetrics()
                windowManager.defaultDisplay.getMetrics(display)
                space.minimumWidth = display.widthPixels
                mainLayout.addView(space)
            }

            mainLayout.addView(linearLayout)
            buttons += buttonStates
        }


        return buttons
    }

    @SuppressLint("ShowToast")
    private fun makeButtonStyle(id: Int, playersButton: ImageButton): ImageButton {
        val button = ImageButton(applicationContext)
        val display = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(display)
        button.minimumWidth = (display.widthPixels / 3.3).toInt()
        button.maxWidth = (display.widthPixels / 3.3).toInt()
        button.minimumHeight = (display.widthPixels / 3.3).toInt()
        button.maxHeight = (display.widthPixels / 3.3).toInt()
        var drawable = GradientDrawable()
        drawable.setColor(Color.LTGRAY)
        drawable.cornerRadius = 25.toFloat()
        button.background = drawable
        button.id = id
        button.scaleType = ImageView.ScaleType.CENTER_INSIDE

        button.setOnClickListener {
            var thisOne = findButtonStateById(button.id)!!
            button.isClickable = false
            if (crossPlays) {
                thisOne.setValue("cross")
                button.setImageResource(R.drawable.x)
                drawable.setColor(Color.rgb(187, 255, 255))
                button.background = drawable
            } else {
                thisOne.setValue("circle")
                button.setImageResource(R.drawable.o)
                drawable.setColor(Color.argb(175, 190, 255, 160))
                button.background = drawable
            }
            thisOne.setClicked(true)
            crossPlays = !crossPlays
            var gameState = checkGameState(buttons!!)
            if (gameState.endGame) {
                var winner = if (gameState.winner.equals("crosses")) "Vyhrály křížky" else if(gameState.winner.equals("circles")) "Vyhrála kolečka" else "Remíza"
                Toast.makeText(applicationContext, "$winner", Toast.LENGTH_LONG).show()
                for (i in 0..2){
                    for (j in 0..2){
                        var btn = buttons!![i][j]
                        var butt = btn.getButton()
                        butt.isEnabled = false
                    }
                }

            }

            setInfoPlayerImage(playersButton,crossPlays)
        }
        return button
    }

    private fun findButtonStateById(id: Int): ButtonState? {
        for (line in buttons!!) {
            for (button in line) {
                if (button.getId() == id) return button
            }
        }
        return null
    }

    private fun setPlayersTurnLayout(crossPlays: Boolean, layout: LinearLayout):LinearLayout {
        val linearLayout = LinearLayout(applicationContext)
        val imageButton = ImageButton(applicationContext)
        val textView = TextView(applicationContext)
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        textView.text = "Právě hraje: "
        textView.textSize = 20F
        textView.textAlignment = View.TEXT_ALIGNMENT_CENTER
        textView.width = metrics.widthPixels / 3
        textView.setTextColor(Color.BLACK)
        imageButton.isClickable = false

        setInfoPlayerImage(imageButton,crossPlays)
        linearLayout.setPadding(0,0,0,50)
        linearLayout.id = 0
        linearLayout.setHorizontalGravity(Gravity.CENTER_HORIZONTAL)
        linearLayout.setVerticalGravity(Gravity.CENTER_VERTICAL)
        linearLayout.addView(textView)
        linearLayout.addView(imageButton, metrics.widthPixels/7 ,metrics.widthPixels/7)
        layout.addView(linearLayout)
        return linearLayout
    }

    private fun setInfoPlayerImage(imageButton: ImageButton, crossPlays: Boolean) {
        val drawable = GradientDrawable()
        drawable.setColor(Color.LTGRAY)
        drawable.cornerRadius = 25F
        imageButton.background = drawable
        imageButton.scaleType = ImageView.ScaleType.CENTER_INSIDE
        if (crossPlays) {
            drawable.setColor(Color.rgb(187, 255, 255))
            imageButton.setImageResource(R.drawable.x)
        } else {
            drawable.setColor(Color.argb(175, 190, 255, 160))
            imageButton.setImageResource(R.drawable.o)
        }

        imageButton.background = drawable
    }
    private fun makeWinnerPopupWindow(winner : String):PopupWindow{
        val winnerPopup = PopupWindow(applicationContext)
        val popupLayout = LinearLayout(applicationContext)
        val winnerTextView = TextView(applicationContext)
        winnerTextView.setTextColor(Color.BLACK)
        winnerTextView.text = if (winner == "crosses") "Vyhrály křižky" else if (winner == "circles") "Vyhrála kolečka" else "Remíza"
        popupLayout.gravity = Gravity.CENTER_VERTICAL
        popupLayout.orientation = LinearLayout.VERTICAL



        return winnerPopup
    }
}
