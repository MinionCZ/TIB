package com.example.tictactoe


import android.widget.ImageButton

class ButtonState(button:ImageButton, id:Int) {
    private var clicked = false
    private var value = "null"
    private var button = button
    private var id = id
    fun getValue():String{
        return value
    }
    fun setValue(value:String){
        this.value = value
    }
    fun isClicked():Boolean{
        return clicked
    }
    fun setClicked(clicked:Boolean){
        this.clicked = clicked
    }
    fun getButton():ImageButton{
        return button
    }

    fun getId():Int{
        return id
    }

}